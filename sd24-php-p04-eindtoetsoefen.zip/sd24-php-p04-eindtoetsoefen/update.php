<?php
session_start();
global $db;
require 'db.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) { header('Location: index.php'); exit; }

/* leerling ophalen */
$stmt = $db->prepare('SELECT * FROM leerling WHERE id = :id');
$stmt->execute(['id' => $id]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$student) { $_SESSION['error'] = 'Leerling niet gevonden.'; header('Location: index.php'); exit; }

$errors = [];
if (isset($_POST['submit'])) {

    $naam = trim($_POST['naam']);
    $klas = trim($_POST['klas']);

    if ($naam === '')   $errors['naam'] = 'Naam is verplicht.';
    if ($klas === '')   $errors['klas'] = 'Klas is verplicht.';

    /* duplicate-check behalve voor jezelf */
    $dup = $db->prepare('SELECT COUNT(*) FROM leerling WHERE naam = :n AND klas = :k AND id != :id');
    $dup->execute(['n' => $naam, 'k' => $klas, 'id' => $id]);
    if ($dup->fetchColumn() > 0) {
        $errors['naam'] = 'Naam + klas bestaat al.';
    }

    if (!$errors) {
        $upd = $db->prepare('UPDATE leerling SET naam = :naam, klas = :klas WHERE id = :id');
        $upd->execute(['naam' => $naam, 'klas' => $klas, 'id' => $id]);

        $_SESSION['message'] = 'Leerling bijgewerkt.';
        header('Location: index.php');
        exit;
    }
}
?>
<!doctype html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Leerling bewerken</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-5">
<h1 class="mb-4">Leerling bewerken</h1>

<form method="post" class="w-50">
    <div class="mb-3">
        <label class="form-label">Naam</label>
        <input type="text" name="naam" class="form-control" value="<?= htmlspecialchars($_POST['naam'] ?? $student['naam']) ?>">
        <div class="text-danger"><?= $errors['naam'] ?? '' ?></div>
    </div>
    <div class="mb-3">
        <label class="form-label">Klas</label>
        <input type="text" name="klas" class="form-control" value="<?= htmlspecialchars($_POST['klas'] ?? $student['klas']) ?>">
        <div class="text-danger"><?= $errors['klas'] ?? '' ?></div>
    </div>

    <button name="submit" class="btn btn-success">Opslaan</button>
    <a href="index.php" class="btn btn-secondary">Annuleren</a>
</form>
</body>
</html>
