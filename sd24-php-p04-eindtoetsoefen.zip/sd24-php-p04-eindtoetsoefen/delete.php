<?php
session_start();
global $db;
require 'db.php';

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) {
    header('Location: index.php');
    exit;
}

/* 1. bestaat leerling? */
$exists = $db->prepare('SELECT COUNT(*) FROM leerling WHERE id = :id');
$exists->execute(['id' => $id]);
if ($exists->fetchColumn() == 0) {
    $_SESSION['error'] = 'Leerling niet gevonden.';
    header('Location: index.php');
    exit;
}

/* 2. afhankelijkheid?  (optioneel kun je eerst toetsen verwijderen) */
$db->prepare('DELETE FROM toets WHERE leerling_id = :id')->execute(['id' => $id]);

/* 3. leerling verwijderen */
$db->prepare('DELETE FROM leerling WHERE id = :id')->execute(['id' => $id]);

$_SESSION['message'] = 'Leerling verwijderd.';
header('Location: index.php');
