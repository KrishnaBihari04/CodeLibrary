<?php
session_start();
global $db;
require 'db.php';

$student_id = filter_input(INPUT_GET, 'leerling_id', FILTER_VALIDATE_INT);
if (!$student_id) {
    header('Location: index.php');
    exit;
}

/* 1. leerling ophalen */
$studentStmt = $db->prepare('SELECT * FROM leerling WHERE id = :id');
$studentStmt->execute(['id' => $student_id]);
$student = $studentStmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    $_SESSION['error'] = 'Leerling niet gevonden.';
    header('Location: index.php');
    exit;
}

/* 2. cijfers ophalen */
$gradesStmt = $db->prepare('SELECT vak, cijfer FROM toets WHERE leerling_id = :id');
$gradesStmt->execute(['id' => $student_id]);
$grades = $gradesStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Cijfers van <?= htmlspecialchars($student['naam']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-5">

<?php /* flash-berichten */ ?>
<?php if (isset($_SESSION['message'])): ?>
    <div class="alert alert-success"><?= $_SESSION['message']; unset($_SESSION['message']); ?></div>
<?php endif; ?>
<?php if (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<h1 class="mb-4">Cijfers van <?= htmlspecialchars($student['naam']) ?> (<?= htmlspecialchars($student['klas']) ?>)</h1>

<table class="table table-striped w-auto">
    <thead><tr><th>Vak</th><th>Cijfer</th></tr></thead>
    <tbody>
    <?php foreach ($grades as $g): ?>
        <tr>
            <td><?= htmlspecialchars($g['vak']) ?></td>
            <td><?= htmlspecialchars($g['cijfer']) ?></td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<a href="index.php" class="btn btn-secondary mt-3">← Terug</a>

</body>
</html>
