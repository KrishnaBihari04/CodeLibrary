<?php
session_start();
require 'db.php';   // maakt $db (PDO) aan

$errors = [];
$naam   = $_POST['naam'] ?? '';
$klas   = $_POST['klas'] ?? '';

/* ────────────── Form verwerkt? ───────────── */
if (isset($_POST['submit'])) {

    /* 1. Basis-validatie */
    if (trim($naam) === '') $errors['naam'] = 'Naam is verplicht.';
    if (trim($klas) === '') $errors['klas'] = 'Klas is verplicht.';

    /* 2. Duplicate-check: zelfde naam + klas mag niet */
    if (!$errors) {
        $dup = $db->prepare('SELECT COUNT(*) FROM leerling WHERE naam = :n AND klas = :k');
        $dup->execute(['n' => $naam, 'k' => $klas]);

        if ($dup->fetchColumn() > 0) {
            $errors['naam'] = 'Deze leerling bestaat al in deze klas.';
        }
    }

    /* 3. Insert wanneer alles oké is */
    if (!$errors) {
        $insert = $db->prepare('INSERT INTO leerling (naam, klas) VALUES (:n, :k)');
        $insert->execute(['n' => $naam, 'k' => $klas]);

        $_SESSION['message'] = 'Leerling succesvol toegevoegd.';
        header('Location: index.php');
        exit;
    }
}
?>
<!doctype html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Leerling toevoegen</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-5">

<h1 class="mb-4">Leerling toevoegen</h1>

<form method="post" class="w-50">
    <!-- Naam -->
    <div class="mb-3">
        <label class="form-label">Naam</label>
        <input type="text"
               name="naam"
               class="form-control <?= isset($errors['naam']) ? 'is-invalid' : '' ?>"
               value="<?= htmlspecialchars($naam) ?>">
        <div class="invalid-feedback"><?= $errors['naam'] ?? '' ?></div>
    </div>

    <!-- Klas -->
    <div class="mb-3">
        <label class="form-label">Klas</label>
        <input type="text"
               name="klas"
               class="form-control <?= isset($errors['klas']) ? 'is-invalid' : '' ?>"
               value="<?= htmlspecialchars($klas) ?>">
        <div class="invalid-feedback"><?= $errors['klas'] ?? '' ?></div>
    </div>

    <button name="submit" class="btn btn-success">Opslaan</button>
    <a href="index.php" class="btn btn-secondary">Annuleren</a>
</form>

</body>
</html>
