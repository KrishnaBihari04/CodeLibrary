<?php
session_start();
global $db;
require 'db.php';              // maakt $db aan


/* ───────────────────────────────── Leerlingen ophalen */
$stmt = $db->query('SELECT * FROM leerling');
$leerlingen = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Toetsresultaten</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-5">

<?php /* ─── Flash-berichten ───────────────────────── */ ?>
<?php if (isset($_SESSION['message'])): ?>
    <div class="alert alert-success"><?= $_SESSION['message']; unset($_SESSION['message']); ?></div>
<?php elseif (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<h1 class="mb-4">Toets-resultaten</h1>

<ul class="list-group mb-4">
    <?php foreach ($leerlingen as $ll): ?>
        <li class="list-group-item d-flex justify-content-between align-items-center">
            <a href="detail.php?leerling_id=<?= $ll['id'] ?>" class="text-decoration-none">
                <?= htmlspecialchars($ll['naam']) ?> <span class="text-muted">(<?= htmlspecialchars($ll['klas']) ?>)</span>
            </a>
            <span>
                <a href="update.php?id=<?= $ll['id'] ?>" class="btn btn-sm btn-outline-primary">✎</a>
                <a href="delete.php?id=<?= $ll['id'] ?>"
                   class="btn btn-sm btn-outline-danger"
                   onclick="return confirm('Weet je zeker dat je deze leerling wilt verwijderen?');">🗑</a>
            </span>
        </li>
    <?php endforeach; ?>
</ul>

<p>Aantal leerlingen: <strong><?= count($leerlingen) ?></strong></p>

<a href="insert.php" class="btn btn-success">Leerling toevoegen</a>

</body>
</html>
