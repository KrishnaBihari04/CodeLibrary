<?php
session_start();
require 'db.php';
global $db;

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) { header('Location: index.php'); exit; }

/* Verwijderen (cascade haalt games ook weg) */
$del = $db->prepare('DELETE FROM platforms WHERE id = :id');
$del->bindValue(':id', $id, PDO::PARAM_INT);
$del->execute();


$_SESSION['message'] = 'Platform verwijderd.';
header('Location: index.php');
?>

