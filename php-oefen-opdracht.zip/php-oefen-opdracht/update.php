<?php
session_start();
require 'db.php';
global $db;

$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) { header('Location: index.php'); exit; }

/* ── Huidige data ─────────────────── */
$get = $db->prepare('SELECT * FROM platforms WHERE id = :id');
$get->bindValue(':id', $id, PDO::PARAM_INT);
$get->execute();
$platform = $get->fetch();
if (!$platform) {
    $_SESSION['error'] = 'Platform niet gevonden.';
    header('Location: index.php');
    exit;
}

$name         = $_POST['name']         ?? $platform['name'];
$manufacturer = $_POST['manufacturer'] ?? $platform['manufacturer'];
$errors = [];

if (isset($_POST['submit'])) {

    if (trim($name) === '')         $errors['name'] = 'Naam is verplicht.';
    if (trim($manufacturer) === '') $errors['manufacturer'] = 'Fabrikant is verplicht.';

    /* Duplicate-check behalve jezelf */
    if (!$errors) {
        $dup = $db->prepare('SELECT COUNT(*) FROM platforms WHERE name = :n AND id <> :id');
        $dup->bindValue(':n',  $name);
        $dup->bindValue(':id', $id, PDO::PARAM_INT);
        $dup->execute();
        if ($dup->fetchColumn() > 0) $errors['name'] = 'Platform bestaat al.';
    }

    if (!$errors) {
        $upd = $db->prepare(
            'UPDATE platforms SET name = :name, manufacturer = :manufacturer WHERE id = :id'
        );
        $upd->bindParam(':name',         $name);
        $upd->bindParam(':manufacturer', $manufacturer);
        $upd->bindParam(':id',           $id, PDO::PARAM_INT);
        $upd->execute();

        $_SESSION['message'] = 'Platform bijgewerkt.';
        header('Location: index.php');
        exit;
    }
}
?>
<!doctype html>
<html lang="nl">
<head>
    <meta charset="utf-8">
    <title>Platform bewerken</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-5">

<a href="index.php" class="btn btn-secondary mb-4">← Terug</a>
<h1 class="mb-4">Platform bewerken</h1>

<form method="post" class="w-50">
    <div class="mb-3">
        <label class="form-label">Naam</label>
        <input type="text" name="name"
               class="form-control <?= isset($errors['name']) ? 'is-invalid' : '' ?>"
               value="<?= htmlspecialchars($name) ?>">
        <div class="invalid-feedback"><?= $errors['name'] ?? '' ?></div>
    </div>

    <div class="mb-3">
        <label class="form-label">Fabrikant</label>
        <input type="text" name="manufacturer"
               class="form-control <?= isset($errors['manufacturer']) ? 'is-invalid' : '' ?>"
               value="<?= htmlspecialchars($manufacturer) ?>">
        <div class="invalid-feedback"><?= $errors['manufacturer'] ?? '' ?></div>
    </div>

    <button name="submit" class="btn btn-success">Opslaan</button>
</form>
</body>
</html>
