<?php
session_start();
require 'db.php';
global $db;

/* Alle platforms ophalen */
$platforms = $db->query('SELECT * FROM platforms ORDER BY name')->fetchAll();
?>
<!doctype html>
<html lang="nl">
<head>
    <meta charset="utf-8">
    <title>Platforms</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-5">

<h1 class="mb-4">Platforms</h1>

<?php if (isset($_SESSION['message'])): ?>
    <div class="alert alert-success"><?= $_SESSION['message']; unset($_SESSION['message']); ?></div>
<?php elseif (isset($_SESSION['error'])): ?>
    <div class="alert alert-danger"><?= $_SESSION['error']; unset($_SESSION['error']); ?></div>
<?php endif; ?>

<table class="table table-striped">
    <thead>
    <tr><th>Naam</th><th>Fabrikant</th><th></th></tr>
    </thead>
    <tbody>
    <?php foreach ($platforms as $p): ?>
        <tr>
            <td><?= htmlspecialchars($p['name']) ?></td>
            <td><?= htmlspecialchars($p['manufacturer']) ?></td>
            <td class="text-end">
                <a href="detail.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-primary">Details</a>
                <a href="update.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-primary">✎</a>
                <a href="delete.php?id=<?= $p['id'] ?>" class="btn btn-sm btn-outline-danger"
                   onclick="return confirm('Weet je zeker dat je dit platform wilt verwijderen?');">🗑</a>
            </td>
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<p>Totaal platforms: <strong><?= count($platforms) ?></strong></p>

<a href="insert.php" class="btn btn-success">Nieuw platform</a>

</body>
</html>
