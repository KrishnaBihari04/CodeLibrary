<?php
session_start();
require 'db.php';
global $db;

/* ── 1. id valideren ────────────────────────────────── */
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
if (!$id) { header('Location: index.php'); exit; }

/* ── 2. Platform ophalen ────────────────────────────── */
$platformStmt = $db->prepare('SELECT * FROM platforms WHERE id = :id');
$platformStmt->bindValue(':id', $id, PDO::PARAM_INT);
$platformStmt->execute();
$platform = $platformStmt->fetch();

if (!$platform) {
    $_SESSION['error'] = 'Platform niet gevonden.';
    header('Location: index.php');
    exit;
}

/* ── 3. Games ophalen (fetchAll!) ───────────────────── */
$gamesStmt = $db->prepare('SELECT * FROM games WHERE platform_id = :id');
$gamesStmt->bindValue(':id', $id, PDO::PARAM_INT);
$gamesStmt->execute();
$games = $gamesStmt->fetchAll();     // ← belangrijk: nu is $games een array
?>
<!doctype html>
<html lang="nl">
<head>
    <meta charset="utf-8">
    <title><?= htmlspecialchars($platform['name']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.6/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="container py-5">

<a href="index.php" class="btn btn-secondary mb-4">← Terug</a>

<h1><?= htmlspecialchars($platform['name']) ?></h1>
<p>Fabrikant: <strong><?= htmlspecialchars($platform['manufacturer']) ?></strong></p>

<h3 class="mt-4">Games</h3>

<?php if (!empty($games)): ?>
    <ul class="list-group mb-3">
        <?php foreach ($games as $g): ?>
            <li class="list-group-item d-flex justify-content-between">
                <?= htmlspecialchars($g['title']) ?>
                <span class="text-muted"><?= htmlspecialchars($g['genre']) ?></span>
            </li>
        <?php endforeach; ?>
    </ul>
<?php else: ?>
    <p class="text-muted">Geen games voor dit platform.</p>
<?php endif; ?>

<p><strong>Totaal aantal games: <?= count($games) ?></strong></p>

</body>
</html>
