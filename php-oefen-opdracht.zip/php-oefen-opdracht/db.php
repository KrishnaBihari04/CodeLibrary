<?php
/* Centrale PDO-verbinding */
$dsn  = 'mysql:host=localhost;dbname=platforms;charset=utf8mb4';
$user = 'root';
$pass = '';

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
];

try {
    $db = new PDO($dsn, $user, $pass, $options);
} catch (PDOException $e) {
    die('Verbinding mislukt: ' . $e->getMessage());
}
?>
